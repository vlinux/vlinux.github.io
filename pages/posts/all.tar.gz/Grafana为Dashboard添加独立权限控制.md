---
title: Grafana为Dashboard添加独立权限控制
categories: Grafana
tags: [Grafana权限控制]
date: 2022-09-30 14:07:17
---
Grafana作为一款开源的度量分析与可视化套件，已经得到了大家的认可并被广泛使用，他可用于基础设施的时序监控数据展示，应用程序数据分析可视化，另外在包括气象、家庭自动化和过程控制等其他领域也使用广泛。Grafana支持Mysql、Elasticsearch、Prometheus、InfluxDB等众多数据源，每个数据源都有一个特定的查询编辑器，可以根据自己的业务需要，撰写多种表达式，绘制多种数据展示图表。但有时你绘制的图表信息，如若涉及敏感信息，不想被所有人看到的时候，该怎么办呢？

## 权限概览

假如你的Grafana接入了登陆控制，无论是采用Grafana自带的权限控制，还是启用了Ldap认证，默认情况下Dashboard对所有人的权限都是可读的；总结Grafana的用户权限受以下几方面因素影响：

- `Organization Role` (Admin, Editor, Viewer)；即全局组织角色
- Via `Team` memberships where the Team has been assigned specific permissions. 即小组权限
- Via permissions assigned directly to user (on `folders`, `dashboards`, `data sources`). 即针对Folder、Dashboard、Data Source特意为某用户分配的权限
- The Grafana Admin (i.e. Super Admin) user flag. 超级管理员权限

为单个Dashboard配置独立权限控制，可在”Dashboard settings”–> “Permissions”–>“Add Permission”，为某用户或小组添加权限；同时Dashboard的权限是继承自所在**Folder**的权限，所以你会看到部分已有权限后面有一个小锁的标志，代表权限不能修改，如若修改，只能通过修改对应Folder的权限；也就是说，**所谓Grafana Dashboard的权限控制，即Folder(文件夹)的权限控制**；

![img](https://cos.vlinux.cn/www-vlinux-cn-blog-img/38f3429a32fc5fc.jpg#mirages-width=800&mirages-height=222&mirages-cdn-type=5)

## Dashboard和Folder权限

为某个Dashboard添加权限控制的操作示例

![img](https://cos.vlinux.cn/www-vlinux-cn-blog-img/ee4865322bfa686.jpg#mirages-width=800&mirages-height=340&mirages-cdn-type=5)

如上图所示，在`Folder`的`Manage`配置项中，可以在这里删除此文件夹的默认角色，然后针对某个用户或小组自定义权限；

### 添加Team

`Configuration`-> `Teams`–> `Add Team`，输入Team名称，即可创建一个新Team；这里我创建了一个名为：“TestReadOnly”的新Team；

![img](https://cos.vlinux.cn/www-vlinux-cn-blog-img/9dd85b57cf27cd7.jpg#mirages-width=800&mirages-height=234&mirages-cdn-type=5)

添加Team User

鼠标点击刚才创建好的Team，`Team Members`处`Add member`可添加用户到此Team中：

![img](https://cos.vlinux.cn/www-vlinux-cn-blog-img/a12a79454f48fcd.jpg#mirages-width=800&mirages-height=332&mirages-cdn-type=5)

#### 为Team配置Dashboard权限

找到`Dashboard settings`或文件夹管理，找到`Permissions`配置，`Add Permission`添加权限，给‘“TestReadOnly”组添加“View”的权限，其他权限删除；这样配置后，**“TestReadyOnly”组中的用户将具有只读权限，而不在此组中的用户则无权限访问**(超级管理员用户的权限不可删除)；配置”Edit”等权限的方法与此类似。

![img](https://cos.vlinux.cn/www-vlinux-cn-blog-img/ac8a3b58bcb53c1.jpg#mirages-width=800&mirages-height=288&mirages-cdn-type=5)

权限级别

Grafana的权限级别主要有三种：**Admin** > **Edit** > **View**

**注意事项：**

1. 不能覆盖具有`组织管理员`角色的用户权限
2. 如果存在具有较高权限级别的规规存在，则低权限级别的权限规则将不生效

比如，这里存在一个文件夹FolderX，如果该文件夹对所有人只读且不可编辑，那么你可以定义一个只读Team，假设名为”ReadOnly”；你已经将包括“xujpxm”在内的几个用户添加到“ReadOnly”组中；这时你将”ReadOnly” Team赋予FolderX文件夹“View”权限，同时删除了“Edit”/”Admin”权限；那么这时在“ReadOnly” Team里的用户将对FolderX文件夹只可读，不可编辑；正常情况下到这一步针对单个文件夹的权限控制已经达到。但需要注意的是，假设“xujpxm”用户也具有管理员权限，权限级别高于“View”，根据`注意事项`1，所以”xujpxm”用户对“FolderX“”文件夹还是可编辑和管理的；第二种情况，假如还有一个“EditGroup” Team，FolderX赋予了其“Edit”权限，但同时用户“xujpxm”(非超级管理员用户)也在其中，那么这时该用户对此文件夹同时有“Edit”和“View”权限，根据`注意事项2`，”xujpxm”用户对此文件夹拥有的是应该“Edit”权限。

